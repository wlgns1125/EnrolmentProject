package persistence.dto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@ToString
public class UserDTO {

    private String ID;
    private String 패스워드;
    private String 사용자구분;



}
